module.exports = {
  name: 'Store Game Info',
  displayName: 'Store Member Game Info',
  section: 'Member Control',
  meta: {
    version: '2.1.7',
    preciseCheck: false,
    author: 'DBM Mods',
    authorUrl: 'https://github.com/dbm-network/mods',
    downloadURL: 'https://github.com/dbm-network/mods/blob/master/actions/store_game_info_MOD.js',
  },

  subtitle(data, presets) {
    const info = [
      'Game Application ID',
      'Game Details',
      'Game Name',
      'Game State',
      'Game Is Being Streamed?',
      'Game Stream URL',
      'Game Status Type',
      'Game Large Image ID',
      'Game Large Image URL',
      'Game Large Image Text',
      'Game Small Image ID',
      'Game Small Image URL',
      'Game Small Image Text',
      'Game Timestamp Start',
      'Game Party ID',
      'Game Timestamp End',
      'Game Party Size',
    ];
    return `${presets.getMemberText(data.member, data.varName)} - ${info[parseInt(data.info, 10)]}`;
  },

  variableStorage(data, varType) {
    if (parseInt(data.storage, 10) !== varType) return;
    let dataType = 'Unknown Type';
    switch (parseInt(data.info, 10)) {
      case 0:
        dataType = 'Application ID';
        break;
      case 1:
        dataType = 'Text';
        break;
      case 2:
        dataType = 'Text';
        break;
      case 3:
        dataType = 'Text';
        break;
      case 4:
        dataType = 'Boolean';
        break;
      case 5:
        dataType = 'Stream URL';
        break;
      case 6:
        dataType = 'Number';
        break;
      case 7:
        dataType = 'Large Image ID';
        break;
      case 8:
        dataType = 'Large Image URL';
        break;
      case 9:
        dataType = 'Large Image Text';
        break;
      case 10:
        dataType = 'Small Image ID';
        break;
      case 11:
        dataType = 'Small Image URL';
        break;
      case 12:
        dataType = 'Small Image Text';
        break;
      case 13:
        dataType = 'Date';
        break;
      case 14:
        dataType = 'Party ID';
        break;
      case 15:
        dataType = 'Date';
        break;
      case 16:
        dataType = 'Number';
        break;
      default:
        break;
    }
    return [data.varName2, dataType];
  },

  fields: ['member', 'varName', 'info', 'storage', 'varName2'],

  html() {
    return `
<div>
  <member-input dropdownLabel="Source Member" selectId="member" variableContainerId="varNameContainer" variableInputId="varName"></member-input>
</div>
<br><br><br>

<div>
  <div style="padding-top: 8px; width: 70%;">
    <span class="dbminputlabel">Source Info</span><br>
    <select id="info" class="round">
      <option value="0">Game Application ID</option>
      <option value="1">Game Details</option>
      <option value="2" selected>Game Name</option>
      <option value="3">Game State</option>
      <option value="4">Game Is Being Streamed?</option>
      <option value="5">Game Stream URL</option>
      <option value="6">Game Status Type</option>
      <optgroup label="Timestamps">
        <option value="13">Game Timestamp Start</option>
        <option value="15">Game Timestamp End</option>
      </optgroup>
      <optgroup label="Party">
        <option value="14">Game Party ID</option>
        <option value="16">Game Party Size</option>
      </optgroup>
      <optgroup label="Assets Large Image">
        <option value="7">Game Large Image ID</option>
        <option value="8">Game Large Image URL</option>
      <option value="9">Game Large Image Text</option>
      </optgroup>
      <optgroup label="Assets Small Image">
        <option value="10">Game Small Image ID</option>
        <option value="11">Game Small Image URL</option>
        <option value="12">Game Small Image Text</option>
      </optgroup>
    </select>
  </div>
</div>
<br>

<div>
  <store-in-variable dropdownLabel="Store In" selectId="storage" variableContainerId="varNameContainer2" variableInputId="varName2"></store-in-variable>
</div>`;
  },

  init() {},

  async action(cache) {
    const data = cache.actions[cache.index];
    const info = parseInt(data.info, 10);
    const mem = await this.getMemberFromData(data.member, data.varName, cache);

    if (!mem || !mem.presence.activities[0]) return this.callNextAction(cache);

    let result = null;
    switch (info) {
      case 0:
        result = mem.presence.activities[0].applicationID;
        break;
      case 1:
        result = mem.presence.activities[0].details;
        break;
      case 2:
        result = mem.presence.activities[0].name;
        break;
      case 3:
        result = mem.presence.activities[0].state;
        break;
      case 4:
        result = mem.presence.activities[0].streaming;
        break;
      case 5:
        result = mem.presence.activities[0].url;
        break;
      case 6:
        result = mem.presence.activities[0].type;
        break;
      case 7:
        result = mem.presence.activities[0].assets.largeImage || null;
        break;
      case 8:
        result = mem.presence.activities[0].assets.largeImageURL || null;
        break;
      case 9:
        result = mem.presence.activities[0].assets.largeText || null;
        break;
      case 10:
        result = mem.presence.activities[0].assets.smallImage || null;
        break;
      case 11:
        result = mem.presence.activities[0].assets.smallImageURL || null;
        break;
      case 12:
        result = mem.presence.activities[0].assets.smallText || null;
        break;
      case 13:
        result = mem.presence.activities[0].timestamps.start || null;
        break;
      case 14:
        result = mem.presence.activities[0].party.id || null;
        break;
      case 15:
        result = mem.presence.activities[0].timestamps.end || null;
        break;
      case 16:
        result = mem.presence.activities[0].party.size || null;
        break;
      default:
        break;
    }

    if (result !== undefined) {
      const storage = parseInt(data.storage, 10);
      const varName2 = this.evalMessage(data.varName2, cache);
      this.storeValue(result, storage, varName2, cache);
    }
    this.callNextAction(cache);
  },

  mod() {},
};
